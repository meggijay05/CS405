#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number must remain directly before user_input
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";

    // Using std::setw(20) limits cin to reading 19 characters + 1 null terminator.
    // This prevents overflowing into the memory space of 'account_number'.
    std::cin >> std::setw(20) >> user_input;

    // Check if the user entered more data than the buffer could hold
    if (std::cin.fail() || std::cin.peek() != '\n' && std::cin.peek() != EOF)
    {
        std::cout << "WARNING: You entered too much data! Only the first 19 characters were used." << std::endl;

        // Clear the error state and ignore the remaining characters in the buffer
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}